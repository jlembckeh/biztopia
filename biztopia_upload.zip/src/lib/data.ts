import type { Article } from './types'

export const articles: Article[] = [
  {
    slug: 'agentes-ia-sin-spam',
    title: 'Agentes de IA que venden sin sonar a spam',
    excerpt: 'Los agentes autónomos ya pueden crear y distribuir contenido multicanal. ¿Cómo usarlos sin quemar a tu audiencia?',
    date: '2025-08-10',
    topic: 'Marketing',
    readMins: 4,
    content: [
      'Los agentes de IA permiten automatizar publicaciones en web y redes. El riesgo: parecer robot y perder confianza.',
      'La clave está en una guía editorial clara, límites de frecuencia y supervisión humana en momentos críticos.'
    ],
    whyItMatters: [
      'La saturación baja la conversión; la calidad y la segmentación la elevan.',
      'Una mala experiencia destruye marca más rápido que 100 posts “meh”.'
    ],
    actions: [
      'Define un “tono de marca” y ejemplos de sí/no.',
      'Establece una cadencia por canal (ej. 2/semana en LinkedIn).',
      'Mide guardrails: tasa de bloqueos, reportes y unsubscribe.'
    ]
  },
  {
    slug: 'checkout-sin-friccion',
    title: 'Retail: hacia un checkout de fricción cero',
    excerpt: 'Los retailers exploran pagos invisibles y tiendas sin cajas. ¿Cuándo tiene sentido?',
    date: '2025-07-28',
    topic: 'Retail',
    readMins: 5,
    content: [
      'La adopción depende del ticket promedio, merma y experiencia del cliente.',
      'Una prueba en tienda piloto permite medir impacto real antes de escalar.'
    ],
    whyItMatters: [
      'Reduce colas y mejora NPS.',
      'Mejora control de inventario y previene pérdidas.'
    ],
    actions: [
      'Selecciona una tienda con alto tráfico para el piloto.',
      'Define métricas: tiempo de compra, merma, satisfacción.',
      'Compara contra la línea base 8-12 semanas.'
    ]
  },
  {
    slug: 'estrategia-conecta-puntos',
    title: 'Estrategia que conecta puntos',
    excerpt: 'Cómo una innovación técnica puede redefinir marketing y P&L al mismo tiempo.',
    date: '2025-08-05',
    topic: 'Negocios',
    readMins: 3,
    content: [
      'Las empresas ganan cuando alinean producto, canal y mensaje bajo una misma hipótesis de valor.',
      'El “por qué ahora” debe sustentarse en datos de cliente, no en modas.'
    ],
    whyItMatters: [
      'Priorizas iniciativas con ROI real.',
      'Evitas “teatro de innovación”.'
    ],
    actions: [
      'Formula “qué debe ser cierto” y pruébalo barato.',
      'Alinea incentivos entre equipos (producto, ventas, data).'
    ]
  },
  {
    slug: 'chips-ia-estrategia',
    title: 'Chips, IA y estrategia: lo que importa al CFO',
    excerpt: 'El boom de GPUs afecta costos y márgenes. El CFO quiere claridad, no hype.',
    date: '2025-08-12',
    topic: 'Tecnología',
    readMins: 4,
    content: [
      'Los costos de inferencia determinan unit economics en productos de IA.',
      'Optimizar modelos y workloads puede ahorrar 30–60%.'
    ],
    whyItMatters: [
      'Mejoras margen bruto en ofertas de IA.',
      'Permite precios más competitivos sin perder rentabilidad.'
    ],
    actions: [
      'Calcula costo por 1k requests, no por mes.',
      'Evalúa compresión, cuantización y lotes.',
      'Considera nubes con descuento por compromiso.'
    ]
  }
]